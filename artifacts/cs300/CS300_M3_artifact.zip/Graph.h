#pragma once
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <queue>
#include <string>
#include <algorithm>

class Graph {
  // prereq -> courses that depend on it
  std::unordered_map<std::string, std::vector<std::string>> adj_;
  // reverse edges: course -> its direct prereqs
  std::unordered_map<std::string, std::vector<std::string>> rev_;

  static std::string up(std::string s) {
    for (auto& c : s) c = (char)std::toupper((unsigned char)c);
    return s;
  }

  bool dfsCycle(const std::string& u,
                std::unordered_map<std::string,int>& color) const {
    // color: 0=white,1=gray,2=black
    auto it = color.find(u);
    if (it!=color.end() && it->second==1) return true;   // back edge
    if (it!=color.end() && it->second==2) return false;  // done
    color[u]=1;
    auto ait = adj_.find(u);
    if (ait!=adj_.end()) {
      for (auto& v : ait->second) {
        if (dfsCycle(v, color)) return true;
      }
    }
    color[u]=2;
    return false;
  }

public:
  void addEdge(const std::string& prereq, const std::string& course) {
    auto A = up(prereq), B = up(course);
    if (!A.empty()) adj_[A].push_back(B);
    // reverse always records that B depends on A (skip empty A)
    if (!A.empty()) rev_[B].push_back(A);
    // ensure keys exist
    if (!adj_.count(B)) adj_[B] = {};
    if (!rev_.count(A) && !A.empty()) rev_[A] = {};
  }

  bool hasCycle() const {
    std::unordered_map<std::string,int> color;
    for (auto& kv : adj_) {
      if (color[kv.first]==0) {
        if (dfsCycle(kv.first, color)) return true;
      }
    }
    return false;
  }

  // Plan courses needed to reach target in a valid order (topological on subgraph)
  // Returns empty if impossible (cycle or target missing)
  std::vector<std::string> planTo(const std::string& target) const {
    std::string T = up(target);
    if (!rev_.count(T) && !adj_.count(T)) return {}; // unknown target

    // Collect all ancestors (prereqs) via reverse edges
    std::unordered_set<std::string> needed;
    std::queue<std::string> q;
    needed.insert(T);
    q.push(T);
    while (!q.empty()) {
      auto cur = q.front(); q.pop();
      auto it = rev_.find(cur);
      if (it!=rev_.end()) {
        for (auto& pre : it->second) {
          if (needed.insert(pre).second) q.push(pre);
        }
      }
    }

    // Kahn topo over induced subgraph of "needed"
    // Build indegree inside that subgraph
    std::unordered_map<std::string,int> indeg;
    for (auto& n : needed) indeg[n]=0;
    for (auto& u : needed) {
      auto ait = adj_.find(u);
      if (ait!=adj_.end()) {
        for (auto& v : ait->second) {
          if (needed.count(v)) indeg[v]++;
        }
      }
    }

    std::queue<std::string> z;
    for (auto& kv : indeg) if (kv.second==0) z.push(kv.first);

    std::vector<std::string> order;
    while (!z.empty()) {
      auto u = z.front(); z.pop();
      order.push_back(u);
      auto ait = adj_.find(u);
      if (ait!=adj_.end()) {
        for (auto& v : ait->second) {
          if (!needed.count(v)) continue;
          if (--indeg[v]==0) z.push(v);
        }
      }
    }

    // If not all "needed" emitted, there is a cycle in the induced subgraph
    if (order.size()!=needed.size()) return {};
    return order;
  }
};