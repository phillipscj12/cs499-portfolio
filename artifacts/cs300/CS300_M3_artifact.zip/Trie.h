#pragma once
#include <unordered_map>
#include <vector>
#include <string>
#include <algorithm>

class Trie {
  struct Node {
    bool end = false;
    std::unordered_map<char, Node*> next;
  };
  Node* root;

  static char up(char c) { return (char)std::toupper((unsigned char)c); }
  void destroy(Node* n) {
    if (!n) return;
    for (auto& kv : n->next) destroy(kv.second);
    delete n;
  }
  void collect(Node* n, std::string& buf, std::vector<std::string>& out) const {
    if (!n) return;
    if (n->end) out.push_back(buf);
    for (auto& kv : n->next) {
      buf.push_back(kv.first);
      collect(kv.second, buf, out);
      buf.pop_back();
    }
  }
public:
  Trie(): root(new Node) {}
  ~Trie(){ destroy(root); }

  void insert(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), up);
    Node* cur = root;
    for (char c : s) {
      if (!cur->next.count(c)) cur->next[c] = new Node();
      cur = cur->next[c];
    }
    cur->end = true;
  }

  std::vector<std::string> startsWith(std::string prefix) const {
    std::transform(prefix.begin(), prefix.end(), prefix.begin(), up);
    Node* cur = root;
    for (char c : prefix) {
      if (!cur->next.count(c)) return {};
      cur = cur->next.at(c);
    }
    std::vector<std::string> out;
    std::string buf = prefix;
    collect(cur, buf, out);
    std::sort(out.begin(), out.end());
    return out; // O(L + k)
  }
};