# animalshelter.py
# Grazioso Salvare dashboard — paged reads + radio filters + chart + map

# --- FORCE LOCAL MONGO FOR THIS APP RUN ---
import os
os.environ["MONGODB_URI"] = "mongodb://travlr_user:Strong_P%40ss_123@127.0.0.1:27017/travlr?authSource=admin"

# Imports
from dash import Dash
import dash_leaflet as dl
from dash import dcc, html, dash_table
from dash.dependencies import Input, Output
import plotly.express as px
import base64, pandas as pd, re, inspect

# Import the repo module AND the class (order matters)
import animal_shelter as as_mod
from animal_shelter import AnimalShelter

# Debug: prove which module & constructor are in use
print("[animal_shelter __file__]", getattr(as_mod, "__file__", "?"))
print("[AnimalShelter.__init__ signature]", inspect.signature(AnimalShelter.__init__))

# Create the repository (don’t pass uri; the class reads MONGODB_URI)
db = AnimalShelter(db_name='travlr', collection_name='outcomes')

# --- helpers ---
def to_df(records):
    df = pd.DataFrame.from_records(records or [])
    if "_id" in df.columns:
        df.drop(columns=["_id"], inplace=True, errors="ignore")
    return df

fallback_cols = [
    "age_upon_outcome","animal_id","animal_type","breed","color",
    "date_of_birth","datetime","monthyear","name","outcome_subtype",
    "outcome_type","sex_upon_outcome","location_lat","location_long",
    "age_upon_outcome_in_weeks"
]
columns = [{"name": c, "id": c, "deletable": False, "selectable": True} for c in fallback_cols]

# --- branding ---
logo_candidates = ["Grazioso Logo.jpg", "grazioso.png", "logo.png"]
logo_path = next((p for p in logo_candidates if os.path.exists(p)), None)
encoded_image, mime = None, None
if logo_path:
    with open(logo_path, "rb") as f:
        encoded_image = base64.b64encode(f.read()).decode()
    mime = "image/jpeg" if logo_path.lower().endswith((".jpg",".jpeg")) else "image/png"

brand_bar = html.Div([
    html.A(
        html.Img(
            src=(f"data:{mime};base64,{encoded_image}" if encoded_image else ""),
            style={"height": "70px"}
        ),
        href="https://www.snhu.edu", target="_blank", title="Grazioso Salvare"
    ),
    html.Div("Dashboard by Chris Phillips — CS-340",
             style={"fontWeight": "bold", "fontSize": "18px"})
], style={"display": "flex", "gap": "16px", "alignItems": "center"})

# --- filters (radio) ---
filters = html.Div([
    html.Div("Filter by Rescue Type:", style={"fontWeight": "bold"}),
    dcc.RadioItems(
        id="filter-type",
        options=[
            {"label": "Water Rescue", "value": "water"},
            {"label": "Mountain/Wilderness Rescue", "value": "mountain"},
            {"label": "Disaster / Individual Tracking", "value": "disaster"},
            {"label": "Reset (All)", "value": "reset"},
        ],
        value="reset",
        labelStyle={"display": "inline-block", "marginRight": "16px"}
    )
])

# --- pager UI ---
pager = html.Div([
    html.Span("Page size:"),
    dcc.Input(id="page-size", type="number", value=10, min=5, max=100, step=5,
              style={"width":"80px","marginRight":"12px"}),
    html.Button("Prev", id="page-prev", n_clicks=0),
    html.Button("Next", id="page-next", n_clicks=0),
    html.Span(id="page-label", style={"marginLeft":"12px"})
], style={"marginTop":"8px"})

# --- table ---
datatable = dash_table.DataTable(
    id='datatable-id',
    columns=columns,
    data=[],  # filled by callback
    page_size=10,                  # client-side page size for the DataTable
    sort_action="native",
    filter_action="native",
    row_selectable="single",
    selected_rows=[0],
    style_table={"overflowX":"auto"},
    style_cell={"textAlign":"left","minWidth":"100px","width":"120px","maxWidth":"280px"},
    style_header={"fontWeight":"bold"}
)

# --- app ---
app = Dash(__name__)
app.layout = html.Div([
    brand_bar,
    html.Hr(),
    filters,
    pager,
    html.Hr(),
    datatable,
    html.Br(), html.Hr(),
    html.Div(className='row', style={'display':'flex','gap':'12px'}, children=[
        html.Div(id='graph-id', className='col s12 m6', style={"flex":1}),
        html.Div(id='map-id', className='col s12 m6', style={"flex":1})
    ])
])

# --- query builder for radio filters ---
def breed_patterns(names):
    # compiled regex objects are allowed inside $in in PyMongo
    return [re.compile(n, re.IGNORECASE) for n in names]

BREEDS_WATER = breed_patterns([
    "Labrador Retriever", "Chesapeake Bay Retriever", "Newfoundland"
])
BREEDS_MOUNTAIN = breed_patterns([
    "German Shepherd", "Alaskan Malamute", "Old English Sheepdog", "Siberian Husky", "Rottweiler"
])
BREEDS_DISASTER = breed_patterns([
    "Doberman Pinscher", "German Shepherd", "Golden Retriever", "Bloodhound", "Rottweiler"
])

DOG_REGEX        = re.compile(r"^\s*dog\s*$", re.IGNORECASE)
INTACT_FEMALE_RX = re.compile(r"^\s*intact\s+female\s*$", re.IGNORECASE)
INTACT_MALE_RX   = re.compile(r"^\s*intact\s+male\s*$", re.IGNORECASE)

def build_query(ft: str) -> dict:
    base = [{"animal_type": DOG_REGEX}]  # always filter to dogs
    if ft == "water":
        base += [
            {"sex_upon_outcome": INTACT_FEMALE_RX},
            {"age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156}},
            {"breed": {"$in": BREEDS_WATER}},
        ]
    elif ft == "mountain":
        base += [
            {"sex_upon_outcome": INTACT_MALE_RX},
            {"breed": {"$in": BREEDS_MOUNTAIN}},
        ]
    elif ft == "disaster":
        base += [
            {"sex_upon_outcome": INTACT_MALE_RX},
            {"age_upon_outcome_in_weeks": {"$gte": 20, "$lte": 300}},
            {"breed": {"$in": BREEDS_DISASTER}},
        ]
    return {"$and": base}

def to_repo_filters(ft: str) -> dict:
    if ft == "reset":
        return {}
    return {"and": build_query(ft)["$and"]}

# --- callbacks ---

# Server-side paging into the DataTable
@app.callback(
    Output('datatable-id','data'),
    Output('page-label','children'),
    Input('filter-type','value'),
    Input('page-prev','n_clicks'),
    Input('page-next','n_clicks'),
    Input('page-size','value'),
    prevent_initial_call=False
)
def update_table(filter_type, prev_clicks, next_clicks, page_size):
    page = 1 + max(0, int(next_clicks or 0) - int(prev_clicks or 0))
    page_size = int(page_size or 10)

    repo_filters = to_repo_filters(filter_type)  # {} or {"and":[...]}
    and_terms = repo_filters.get("and")
    q = {"$and": and_terms} if isinstance(and_terms, list) and and_terms else {}

    # Preferred path if your AnimalShelter has list_animals()
    if hasattr(db, "list_animals"):
        res = db.list_animals(repo_filters, page=page, page_size=page_size)
        label = f"Page {res['page']} · showing {len(res['items'])} of {res['total']}"
        return res["items"], label

    # Fallback path — use a proper dict query
    records = db.read(q)
    items = to_df(records).to_dict("records")
    label = f"Page 1 · showing {len(items)} (no paging)"
    return items, label

def update_map(viewData, selected_rows):
    dff = to_df(viewData)
    if dff.empty:
        return [html.Div("No records.")]
    row_idx = 0 if not selected_rows else selected_rows[0]
    row = dff.iloc[row_idx]

    lat = row.get("location_lat", 30.75)
    lon = row.get("location_long", -97.48)
    breed = row.get("breed","Unknown")
    name = row.get("name","Unknown")

    return [dl.Map(style={'width':'100%','height':'500px'}, center=[lat,lon], zoom=10, children=[
        dl.TileLayer(id="base-layer-id"),
        dl.Marker(position=[lat,lon], children=[
            dl.Tooltip(str(breed)),
            dl.Popup([html.H4("Animal"), html.P(str(name))])
        ])
    ])]

if __name__ == "__main__":
    app.run(debug=True, port=8050, use_reloader=False)
