// app_api/models/Trip.js
const mongoose = require('mongoose');

const TripSchema = new mongoose.Schema(
  {
    code: {
      type: String,
      required: true,
      trim: true,
      uppercase: true,
    },
    title: {
      type: String,
      required: true,
      trim: true,
      maxlength: 120,
    },
    summary: {
      type: String,
      required: true,
      trim: true,
      maxlength: 500,
    },
    price: {
      type: Number,
      required: true,
      min: 0,
    },
    nights: {
      type: Number,
      required: true,
      min: 1,
      max: 30,
    },
    image: {
      type: String,
      required: true, // e.g. "/img/beach.jpg"
      trim: true,
    },
  },
  { timestamps: true }
);

// Helpful indexes
TripSchema.index({ title: 'text', summary: 'text' });

module.exports = mongoose.models.Trip || mongoose.model('Trip', TripSchema, 'trips');
