﻿const { Schema, model } = require("mongoose");

const UserSchema = new Schema({
  email:    { type: String, required: true, unique: true, lowercase: true, trim: true },
  name:     { type: String, required: true, trim: true },
  password: { type: String, required: true }, // hashed
  role:     { type: String, enum: ["admin","analyst","viewer"], default: "viewer" }
}, { timestamps: true });

module.exports = model("User", UserSchema);


