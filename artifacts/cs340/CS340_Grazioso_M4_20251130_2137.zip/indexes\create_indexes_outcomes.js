db = db.getSiblingDB("aac");
const col = db.getCollection("outcomes");

// helpful singles
col.createIndex({ animal_type: 1 });
col.createIndex({ breed: 1 });
col.createIndex({ outcome_type: 1 });
col.createIndex({ datetime: -1 });

// compound for common filter+sort
col.createIndex({ animal_type: 1, breed: 1, outcome_type: 1, datetime: -1 });

// text search (optional)
col.createIndex({ name: "text", breed: "text" }, { name: "idx_text_name_breed" });
