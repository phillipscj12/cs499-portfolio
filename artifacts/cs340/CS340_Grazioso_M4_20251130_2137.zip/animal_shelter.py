# animal_shelter.py — local/portable repo wrapper for Mongo
import os
from typing import Dict, Any, Tuple, List, Optional
from pymongo import MongoClient, DESCENDING

class AnimalShelter:
    """
    Preferred usage:
        # let MONGODB_URI drive the connection
        os.environ["MONGODB_URI"] = "mongodb://USER:PASS@127.0.0.1:27017/travlr?authSource=admin"
        db = AnimalShelter(db_name="travlr", collection_name="outcomes")

    Backward-compatible usage (if no URI set):
        db = AnimalShelter(username="user", password="pass", host="127.0.0.1", port=27017,
                           db_name="travlr", collection_name="outcomes", authSource="admin")
    """

    def __init__(
        self,
        db_name: str = "travlr",
        collection_name: str = "outcomes",
        uri: Optional[str] = None,
        *,
        username: Optional[str] = None,
        password: Optional[str] = None,
        host: str = "127.0.0.1",
        port: int = 27017,
        authSource: str = "admin"
    ):
        # 1) Use explicit uri arg if provided
        # 2) Else use env var MONGODB_URI
        # 3) Else build a URI from discrete params
        uri_final = (
            uri
            or os.getenv("MONGODB_URI")
            or (
                f"mongodb://{username or 'travlr_user'}:"
                f"{password or 'Strong_P%40ss_123'}@{host}:{port}/{db_name}?authSource={authSource}"
            )
        )

        self.client = MongoClient(uri_final)
        self.db = self.client[db_name]
        self.col = self.db[collection_name]

    # ========== Basic ops ==========
    def create(self, doc: Dict[str, Any]) -> Any:
        return self.col.insert_one(doc)

    def read(self, query: Dict[str, Any]) -> List[Dict[str, Any]]:
        if not isinstance(query, dict):
            raise ValueError("Query must be a dict.")
        return list(self.col.find(query))

    def update(self, query: Dict[str, Any], new_values: Dict[str, Any]) -> Any:
        return self.col.update_many(query, {"$set": new_values})

    def delete(self, query: Dict[str, Any]) -> Any:
        return self.col.delete_many(query)

    # ========== Paged list with optional filters ==========
    def list_animals(
        self,
        filters: Dict[str, Any],
        page: int = 1,
        page_size: int = 25,
        sort: Tuple[str, int] = ("datetime", DESCENDING),
    ) -> Dict[str, Any]:
        # filters can be {} or {"and":[ {…}, {…} ]}
        q: Dict[str, Any] = {}
        if isinstance(filters, dict) and filters.get("and"):
            q = {"$and": filters["and"]}

        page = max(1, int(page or 1))
        page_size = max(5, min(200, int(page_size or 25)))
        skip = (page - 1) * page_size

        projection = {
            "_id": 0,
            "age_upon_outcome": 1,
            "animal_id": 1,
            "animal_type": 1,
            "breed": 1,
            "color": 1,
            "date_of_birth": 1,
            "datetime": 1,
            "monthyear": 1,
            "name": 1,
            "outcome_subtype": 1,
            "outcome_type": 1,
            "sex_upon_outcome": 1,
            "location_lat": 1,
            "location_long": 1,
            "age_upon_outcome_in_weeks": 1,
        }

        cur = (
            self.col.find(q, projection)
            .sort([sort])
            .skip(skip)
            .limit(page_size)
        )
        items: List[Dict[str, Any]] = list(cur)
        total = self.col.count_documents(q)

        return {
            "items": items,
            "total": total,
            "page": page,
            "pageSize": page_size,
            "hasNext": (skip + len(items)) < total,
        }

    # ========== Aggregations (optional cards) ==========
    def top_breeds(self, animal_type: Optional[str] = None, top: int = 10):
        pipeline = []
        if animal_type:
            pipeline.append({"$match": {"animal_type": animal_type}})
        pipeline += [
            {"$group": {"_id": "$breed", "count": {"$sum": 1}}},
            {"$sort": {"count": -1}},
            {"$limit": int(top)},
        ]
        return list(self.col.aggregate(pipeline))

    def monthly_outcomes(self, months: int = 6):
        pipeline = [
            {
                "$group": {
                    "_id": {
                        "y": {"$year": "$datetime"},
                        "m": {"$month": "$datetime"},
                        "outcome": "$outcome_type",
                    },
                    "count": {"$sum": 1},
                }
            },
            {"$sort": {"_id.y": 1, "_id.m": 1, "count": -1}},
        ]
        return list(self.col.aggregate(pipeline))
