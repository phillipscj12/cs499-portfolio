module.exports = function handleErrors(err, req, res, next) {
  const status = err.status || 500;
  const code = err.code || 'internal_error';
  const message = status === 500 ? 'unexpected error' : (err.message || code);
  res.status(status).json({ error: code, message });
};