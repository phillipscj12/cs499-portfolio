// Role-based guard: authorize('admin'), authorize('admin','analyst'), etc.
module.exports = function authorize(...allowed) {
  return (req, res, next) => {
    try {
      if (!req.user || !allowed.includes(req.user.role)) {
        return res.status(403).json({ error: 'forbidden' });
      }
      next();
    } catch (e) { next(e); }
  };
};