// ProjectTwo.cpp
// CS 300 Project Two – Advising Assistance Program
// Implements menu, file loading, course listing, and course lookup
// Author: Christopher Phillips
// Date: April 20, 2025

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>
#include <cctype>
#include "Trie.h"
#include "Graph.h"
#include "Bloom.h"

static Trie  gTrie;
static Graph gGraph;
static Bloom gBloom(100000, 7); 


// --- Data structure for a course ----------------------------------------
struct Course {
    std::string number;               // e.g. "CSCI200"
    std::string title;                // e.g. "Data Structures"
    std::vector<std::string> prereqs; // list of courseNumbers
};

// Global storage for all loaded courses
static std::vector<Course> courses;
static bool dataLoaded = false;

// Utility: convert string to uppercase for case‑insensitive compare
std::string toUpper(const std::string &s) {
    std::string out = s;
    for (char &c : out) c = std::toupper(static_cast<unsigned char>(c));
    return out;
}

static std::string trim(const std::string& s){
    size_t i=0,j=s.size();
    while(i<j && std::isspace(static_cast<unsigned char>(s[i]))) ++i;
    while(j>i && std::isspace(static_cast<unsigned char>(s[j-1]))) --j;
    return s.substr(i,j-i);
}
static std::string stripQuotes(const std::string& s){
    if(s.size()>=2 && s.front()=='"' && s.back()=='"') return s.substr(1, s.size()-2);
    return s;
}
// Step 1 & 3: Load courses from CSV file into 'courses' vector -----------
void loadData() {
    std::cout << "Enter course data file name: ";
    std::string filename;
    std::getline(std::cin, filename);

    filename = stripQuotes(trim(filename));
    std::cout << "[debug] attempting to open: " << filename << "\n";

    std::ifstream fin(filename);
    if (!fin) {
        std::cerr << "Error: cannot open file \"" << filename << "\"\n";
        return;
    }

    courses.clear();
    std::string line;
    size_t lineNo = 0;
    while (std::getline(fin, line)) {
        ++lineNo;
        if (line.empty()) continue;
        std::stringstream ss(line);
        Course c;

        if (!std::getline(ss, c.number, ',')) { 
            std::cerr << "[debug] bad line " << lineNo << "\n"; 
            continue; 
        }
        std::getline(ss, c.title, ',');

        std::string pre;
        while (std::getline(ss, pre, ',')) {
            if (!pre.empty()) c.prereqs.push_back(toUpper(pre));
        }
        c.number = toUpper(c.number);
        courses.push_back(c);
    }
    fin.close();

    dataLoaded = true;
    std::cout << "Data loaded. " << courses.size() << " courses available.\n";
    std::cout.flush();
}


// Step 4: Print sorted alphanumeric course list --------------------------
void printCourseList() {
    if (!dataLoaded) {
        std::cout << "Error: Data not loaded. Please choose option 1 first.\n";
        return;
    }
    // sort by course.number
    std::sort(courses.begin(), courses.end(),
        [](auto &a, auto &b){
            return a.number < b.number;
        });
    std::cout << "Here is a sample schedule:\n";
    for (auto &c : courses) {
        std::cout << c.number << ", " << c.title << "\n";
    }
}

// Step 5: Print details for a single course ------------------------------
void printCourseInfo() {
    if (!dataLoaded) {
        std::cout << "Error: Data not loaded. Please choose option 1 first.\n";
        return;
    }
    std::cout << "What course do you want to know about? ";
    std::string query;
    std::getline(std::cin, query);
    query = toUpper(query);

    // find course by number
    auto it = std::find_if(courses.begin(), courses.end(),
        [&](auto &c){ return c.number == query; });
    if (it == courses.end()) {
        std::cout << "Course " << query << " not found.\n";
        return;
    }
    // print course title
    std::cout << it->number << ", " << it->title << "\n";
    // print prerequisites
    if (it->prereqs.empty()) {
        std::cout << "Prerequisites: None\n";
    } else {
        std::cout << "Prerequisites: ";
        for (size_t i = 0; i < it->prereqs.size(); ++i) {
            std::cout << it->prereqs[i];
            if (i + 1 < it->prereqs.size())
                std::cout << ", ";
        }
        std::cout << "\n";
    }
}

// Display menu options
void displayMenu() {
    std::cout << "\nWelcome to the course planner.\n"
              << "1. Load Data Structure.\n"
              << "2. Print Course List.\n"
              << "3. Print Course.\n"
              << "4. Search by prefix.\n"          // NEW
              << "5. Show plan to course.\n"       // NEW
              << "9. Exit.\n"
              << "What would you like to do? ";
}

int main() {
    while (true) {
        displayMenu();
        std::string choice;
        std::getline(std::cin, choice);

        if (choice == "1") {
            loadData();
        }
        else if (choice == "2") {
            printCourseList();
        }
        else if (choice == "3") {
            printCourseInfo();
        }
        else if (choice == "4") {
    if (!dataLoaded) {
        std::cout << "Error: Data not loaded. Please choose option 1 first.\n";
    } else {
        std::cout << "Enter code prefix (e.g., CS3): ";
        std::string prefix; std::getline(std::cin, prefix);
        prefix = toUpper(trim(prefix));     // ← normalize

        auto matches = gTrie.startsWith(prefix);
        if (matches.empty()) {
            std::cout << "No matches.\n";
        } else {
            std::cout << "Matches (" << matches.size() << "):\n";
            for (auto& c : matches) std::cout << "  " << c << "\n";
        }
    }
}

        else if (choice == "5") {   // plan to course (Graph)
            if (!dataLoaded) {
                std::cout << "Error: Data not loaded. Please choose option 1 first.\n";
            } else {
                std::cout << "Enter target course (e.g., CS320): ";
                std::string target; std::getline(std::cin, target);

                if (gGraph.hasCycle()) {
                    std::cout << "Cannot plan: cycle detected in prerequisites.\n";
                } else {
                    auto plan = gGraph.planTo(target);
                    if (plan.empty()) {
                        std::cout << "No plan (unknown course or cycle in subgraph).\n";
                    } else {
                        std::cout << "Valid order to reach " << toUpper(target) << ":\n";
                        for (auto& c : plan) std::cout << "  " << c << "\n";
                    }
                }
            }
        }
        else if (choice == "9") {
            std::cout << "Thank you for using the course planner!\n";
            break;
        }
        else {
            std::cout << choice << " is not a valid option.\n";
        }
    }
    return 0;
}
