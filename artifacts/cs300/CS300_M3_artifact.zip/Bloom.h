#pragma once
#include <vector>
#include <string>
#include <functional>

class Bloom {
  size_t m_; // bits
  size_t k_; // hash functions
  std::vector<unsigned char> bits_;

  static inline size_t bitIndex(size_t i) { return i >> 3; }
  static inline unsigned char bitMask(size_t i) { return (unsigned char)(1u << (i & 7u)); }

  size_t h(const std::string& s, size_t seed) const {
    // simple double-hash using std::hash plus a seed mix
    size_t h1 = std::hash<std::string>{}(s);
    size_t h2 = std::hash<std::string>{}(std::to_string(seed) + s);
    return (h1 + seed * 0x9e3779b97f4a7c15ULL + (h2<<6) + (h2>>2)) % m_;
  }

public:
  Bloom(size_t m_bits = 100000, size_t k_hashes = 7)
    : m_(m_bits), k_(k_hashes), bits_((m_bits + 7) / 8, 0) {}

  void add(const std::string& s) {
    for (size_t i=0;i<k_;++i) {
      size_t idx = h(s, i);
      bits_[bitIndex(idx)] |= bitMask(idx);
    }
  }

  bool possiblyContains(const std::string& s) const {
    for (size_t i=0;i<k_;++i) {
      size_t idx = h(s, i);
      if ((bits_[bitIndex(idx)] & bitMask(idx)) == 0) return false;
    }
    return true; // could be false positive, but never a false negative
  }
};