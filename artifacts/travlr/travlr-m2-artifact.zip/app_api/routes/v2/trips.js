const express = require('express');
const { Types } = require('mongoose');
const Trip = require('../../models/Trip');

const requireAuth = require('../../middleware/requireAuth');
const authorize   = require('../../middleware/authorize');
const { audit }   = require('../../audit/auditLogger');
const paginate    = require('../../utils/paginate');

const router = express.Router();

/**
 * GET /api/v2/trips?search=&page=&pageSize=
 * Public list with stable pagination and minimal projection.
 */
router.get('/trips', async (req, res, next) => {
  try {
    const { page, pageSize, skip } = paginate(req);
    const q = {};
    if (req.query.search) {
      q.title = { $regex: req.query.search, $options: 'i' };
    }

    const projection = { title: 1, summary: 1, price: 1 };
    const [items, total] = await Promise.all([
      Trip.find(q, projection).skip(skip).limit(pageSize).lean(),
      Trip.countDocuments(q)
    ]);

    res.json({
      items,
      total,
      page,
      pageSize,
      hasNext: skip + items.length < total
    });
  } catch (e) { next(e); }
});

/**
 * POST /api/v2/trips
 * Admin-only create. Auth → RBAC → Audit.
 */
router.post(
  '/trips',
  requireAuth,
  authorize('admin'),
  audit('trips.create'),
  async (req, res, next) => {
    try {
      const { title, summary, price, nights, image, code } = req.body || {};
      if (!title || typeof title !== 'string') {
        return res.status(400).json({ error: 'bad_request', message: 'title is required' });
      }
      if (price != null && typeof price !== 'number') {
        return res.status(400).json({ error: 'bad_request', message: 'price must be a number' });
      }

      const doc = await Trip.create({ title, summary, price, nights, image, code });
      req.auditPayload = { _id: doc._id, title: doc.title };
      res.status(201).json({ id: doc._id });
    } catch (e) { next(e); }
  }
);

/**
 * GET /api/v2/trip/:id
 * Public read of a single trip by id.
 */
router.get('/trip/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    if (!Types.ObjectId.isValid(id)) {
      return res.status(400).json({ error: 'bad_request', message: 'invalid id' });
    }
    const doc = await Trip.findById(id).lean();
    if (!doc) return res.status(404).json({ error: 'not_found' });
    res.json(doc);
  } catch (e) { next(e); }
});

/**
 * PATCH /api/v2/trip/:id
 * Admin-only partial update. Auth → RBAC → Audit.
 */
router.patch(
  '/trip/:id',
  requireAuth,
  authorize('admin'),
  audit('trips.update'),
  async (req, res, next) => {
    try {
      const { id } = req.params;
      if (!Types.ObjectId.isValid(id)) {
        return res.status(400).json({ error: 'bad_request', message: 'invalid id' });
      }

      // allow only safe fields
      const allowed = ['title', 'summary', 'price', 'nights', 'image', 'code'];
      const updates = {};
      for (const k of allowed) {
        if (k in req.body) updates[k] = req.body[k];
      }
      if (Object.keys(updates).length === 0) {
        return res.status(400).json({ error: 'bad_request', message: 'no valid fields to update' });
      }

      const doc = await Trip.findByIdAndUpdate(id, { $set: updates }, { new: true, runValidators: true }).lean();
      if (!doc) return res.status(404).json({ error: 'not_found' });

      req.auditPayload = { _id: doc._id, updated: Object.keys(updates) };
      res.json({ ok: true });
    } catch (e) { next(e); }
  }
);

/**
 * DELETE /api/v2/trip/:id
 * Admin-only delete. Auth → RBAC → Audit.
 */
router.delete(
  '/trip/:id',
  requireAuth,
  authorize('admin'),
  audit('trips.delete'),
  async (req, res, next) => {
    try {
      const { id } = req.params;
      if (!Types.ObjectId.isValid(id)) {
        return res.status(400).json({ error: 'bad_request', message: 'invalid id' });
      }

      const doc = await Trip.findByIdAndDelete(id).lean();
      if (!doc) return res.status(404).json({ error: 'not_found' });

      req.auditPayload = { _id: doc._id, title: doc.title };
      res.status(204).send();
    } catch (e) { next(e); }
  }
);

module.exports = router;
