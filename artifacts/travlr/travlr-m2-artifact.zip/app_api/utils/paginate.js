module.exports = function paginate(req) {
  const page = Math.max(parseInt(req.query.page ?? '1', 10), 1);
  const pageSize = Math.min(Math.max(parseInt(req.query.pageSize ?? '10', 10), 1), 100);
  const skip = (page - 1) * pageSize;
  return { page, pageSize, skip };
};