const mongoose = require('mongoose');

const auditSchema = new mongoose.Schema({
  ts: { type: Date, default: Date.now },
  userId: String,
  email: String,
  role: String,
  method: String,
  action: String,   // e.g., 'trips.create'
  path: String,
  payload: Object,  // keep minimal; no secrets
  ip: String,
  ua: String
}, { versionKey: false });

const AuditLog = mongoose.model('audit_logs', auditSchema, 'audit_logs');

function audit(action) {
  return (req, res, next) => {
    res.on('finish', async () => {
      try {
        if (!['POST','PUT','PATCH','DELETE'].includes(req.method)) return;
        await AuditLog.create({
          userId: req.user?.id,
          email:  req.user?.email,
          role:   req.user?.role,
          method: req.method,
          action,
          path:   req.originalUrl,
          payload: req.auditPayload || {},
          ip: req.ip,
          ua: req.headers['user-agent']
        });
      } catch (_) { /* never throw from audit */ }
    });
    next();
  };
}

module.exports = { audit };